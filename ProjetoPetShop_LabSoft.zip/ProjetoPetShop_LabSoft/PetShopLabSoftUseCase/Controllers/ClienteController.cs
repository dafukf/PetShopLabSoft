﻿
using PetShopLabSoftUseCase.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.Threading.Tasks;

namespace appPetShop.Controllers
{
    [Authorize]
    public class ClienteController : Controller
    {
        private readonly DbPetShopContext _context;

        public ClienteController(DbPetShopContext context)
        {
            _context = context;
        }

        // Método para gerar Hash SHA-256 do CPF
        private string GerarHashCpf(string cpf)
        {
            if (string.IsNullOrWhiteSpace(cpf))
                return string.Empty;

            // Remove pontos, traços e outros caracteres
            string cpfLimpo = string.Concat(
                Array.FindAll(cpf.ToCharArray(), char.IsDigit));

            // Converte para bytes UTF-8
            byte[] inputBytes = Encoding.UTF8.GetBytes(cpfLimpo);

            // Gera Hash SHA-256
            byte[] hashBytes = SHA256.HashData(inputBytes);

            // Retorna hexadecimal com 64 caracteres
            return Convert.ToHexString(hashBytes).ToLowerInvariant();
        }

        // GET: Cliente
        public async Task<IActionResult> Index()
        {
            return View(await _context.Clientes.ToListAsync());
        }

        // GET: Cliente/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
                return NotFound();

            var cliente = await _context.Clientes
                .FirstOrDefaultAsync(m => m.Codigo == id);

            if (cliente == null)
                return NotFound();

            return View(cliente);
        }

        // GET: Cliente/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Cliente/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(
            [Bind("Codigo,Nome,Cpf,Telefone,DataNascimento")]
            Cliente cliente)
        {
            if (ModelState.IsValid)
            {
                // Aplica Hash no CPF antes de salvar
                cliente.Cpf = GerarHashCpf(cliente.Cpf);

                _context.Add(cliente);

                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }

            return View(cliente);
        }

        // GET: Cliente/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
                return NotFound();

            var cliente = await _context.Clientes.FindAsync(id);

            if (cliente == null)
                return NotFound();

            return View(cliente);
        }

        // POST: Cliente/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(
            int id,
            [Bind("Codigo,Nome,Cpf,Telefone,DataNascimento")]
            Cliente cliente)
        {
            if (id != cliente.Codigo)
                return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    // Recupera o cliente original do banco
                    var clienteExistente =
                        await _context.Clientes.FindAsync(id);

                    if (clienteExistente == null)
                        return NotFound();

                    // Se o CPF foi alterado, gera um novo Hash
                    if (cliente.Cpf != clienteExistente.Cpf)
                    {
                        cliente.Cpf = GerarHashCpf(cliente.Cpf);
                    }

                    // Atualiza os demais dados
                    clienteExistente.Nome = cliente.Nome;
                    clienteExistente.Cpf = cliente.Cpf;
                    clienteExistente.Telefone = cliente.Telefone;
                    clienteExistente.DataNascimento =
                        cliente.DataNascimento;

                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ClienteExists(cliente.Codigo))
                        return NotFound();

                    throw;
                }

                return RedirectToAction(nameof(Index));
            }

            return View(cliente);
        }

        // GET: Cliente/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
                return NotFound();

            var cliente = await _context.Clientes
                .FirstOrDefaultAsync(m => m.Codigo == id);

            if (cliente == null)
                return NotFound();

            return View(cliente);
        }

        // POST: Cliente/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var cliente = await _context.Clientes.FindAsync(id);

            if (cliente != null)
            {
                _context.Clientes.Remove(cliente);
            }

            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        // Verifica se o cliente existe
        private bool ClienteExists(int id)
        {
            return _context.Clientes.Any(e => e.Codigo == id);
        }
    }
}
