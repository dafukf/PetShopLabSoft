﻿using PetShopLabSoftUseCase.Models;
using System;
using System.Collections.Generic;

namespace PetShopLabSoftUseCase.Models;

public partial class Cliente
{
    public int Codigo { get; set; }

    public string Nome { get; set; } = null!;

    public string Cpf { get; set; } = null!;

    public string Telefone { get; set; } = null!;

    public DateOnly DataNascimento { get; set; }

    public virtual ICollection<ReservaServico> ReservaServicos { get; set; } = new List<ReservaServico>();
}