﻿using System.ComponentModel.DataAnnotations;

namespace PetShopLabSoftUseCase.Models
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = "Informe o username.")]
        [Display(Name = "Username")]
        public string Username { get; set; } = string.Empty;

        [Required(ErrorMessage = "Informe a senha.")]
        [DataType(DataType.Password)]
        [Display(Name = "Senha")]
        public string Senha { get; set; } = string.Empty;
    }
}